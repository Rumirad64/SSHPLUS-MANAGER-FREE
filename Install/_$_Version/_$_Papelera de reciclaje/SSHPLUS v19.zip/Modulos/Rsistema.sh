#!/bin/bash
echo -e "\033[1;31mREINICIANDO...\033[0m"
shutdown -r now